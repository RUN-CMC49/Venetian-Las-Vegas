/* Final Project: Venetian Resort Guest Room Booking Template.
By Katelyn H. */

package com.venetiansuite.service;

import com.venetiansuite.model.Guest;
import com.venetiansuite.model.Reservation;
import com.venetiansuite.model.Room;

public class ReservationService {
    public Room getRoomByChoice(int suiteChoiceGuest) {
        // Implement logic to get room by choice
        return new Room("Sample Suite", "Sample Upgrades", 0.0);
    }

    public Reservation bookRoom(Guest guest, Room room, String checkInDate, String checkOutDate) {
        // Implement logic to book room
        return new Reservation(guest, room, checkInDate, checkOutDate);
    }
}