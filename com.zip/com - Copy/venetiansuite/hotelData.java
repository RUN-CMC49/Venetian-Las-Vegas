/* Final Project: Venetian Suites List, Costs and Upgrades. 
By Katelyn H. */
package com.venetiansuite;

public class hotelData {
        // Declare an array of 10 strings of suites
        String[] suiteChoice = new String[] {
                        "1. Venetian Luxury King",
                        "2. Venetian Luxury Two Queen",
                        "3. Venetian Preminum Two Queen",
                        "4. Venetian Preminum King Suite.",
                        "5. Venetian Grand One Bedroom Suite",
                        "6. Palazzo Luxury King",
                        "7. Palazzo Luxury Two Queen",
                        "8. Palazzo Preminium Two Queen",
                        "9. Palazzo Grand 1 Bedroom King Suite",
                        "10. Palazzo Grand 1 Bedroom 2 Queen Suite"
        };

        double SUITE_PRICE = 0.0;

        // Declare an array of 4 different upgrades for rooms
        String[] UPGRADE_SUITE = new String[] {
                        "A. Sphere View \n",
                        "B. Strip View \n",
                        "C. Prestige Club Lounge Access \n",
                        "D. Renovated Suite \n"
        };

        // Declare an array of upgrade prices for rooms
        double[] UPGRADE_PRICES = new double[] {
                        50.0, // Sphere View
                        40.0, // Strip View
                        100.0, // Prestige Club Lounge Access
                        30.0 // Renovated Suite
        };

        // Declare an array of all prices of suite rates in USD
        double[] SUITE_RATES = new double[] {
                        219.25, // Venetian Luxury King
                        226.75, // Venetian Luxury Two Queen
                        264.25, // Venetian Premium Two Queen
                        279.25, // Venetian Premium King Suite
                        485.50, // Venetian Grand One Bedroom Suite
                        219.25, // Palazzo Luxury King
                        226.75, // Palazzo Luxury Two Queen
                        459.25, // Palazzo Premium Two Queen
                        556.75, // Palazzo Grand 1 Bedroom King Suite
                        571.75 // Palazzo Grand 1 Bedroom 2 Queen Suite
        };

        // Declare resort fee in USD
        double RESORT_FEE = 45.0;
}