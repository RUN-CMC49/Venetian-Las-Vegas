/* Final Project: Venetian Resort Invoice Handling Sequence.
By Katelyn H. */

package com.venetiansuite.util;

import com.venetiansuite.model.Reservation;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class FileUtil {
    public static void saveReservationToFile(Reservation reservation) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("reservation.txt"))) {
            writer.write("Guest Name: " + reservation.getGuest().getName() + "\n");
            writer.write("Suite Type: " + reservation.getRoom().getSuiteType() + "\n");
            writer.write("Upgrades: " + reservation.getRoom().getUpgrades() + "\n");
            writer.write("Total Price: $" + reservation.getRoom().getTotalPrice() + "\n");
            writer.write("Check-In Date: " + reservation.getCheckInDate() + "\n");
            writer.write("Check-Out Date: " + reservation.getCheckOutDate() + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}