
/* Program: Venetian Booking Program
By Katelyn H. */

package com.venetiansuite;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Scanner;
import com.venetiansuite.model.Guest;
import com.venetiansuite.model.Reservation;
import com.venetiansuite.model.Room;
import com.venetiansuite.service.ReservationService;
import com.venetiansuite.util.FileUtil;

public class Booking extends JFrame {
    private JTextField nameField, emailField, rewardsIdField, creditCardField, checkInField, checkOutField;
    private JComboBox<String> suiteComboBox;
    private JTextArea upgradesArea;
    private JLabel suiteImageLabel;
    private hotelData hotelData;

    public Booking() {
        hotelData = new hotelData();
        setTitle("The Venetian Resort Las Vegas");
        setSize(700, 900);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel inputPanel = new JPanel(new GridLayout(8, 2));
        inputPanel.add(new JLabel("Enter your full name:"));
        nameField = new JTextField();
        inputPanel.add(nameField);

        inputPanel.add(new JLabel("Enter your email:"));
        emailField = new JTextField();
        inputPanel.add(emailField);

        inputPanel.add(new JLabel("Enter your Venetian Rewards ID:"));
        rewardsIdField = new JTextField();
        inputPanel.add(rewardsIdField);

        inputPanel.add(new JLabel("Enter your credit card number:"));
        creditCardField = new JTextField();
        inputPanel.add(creditCardField);

        inputPanel.add(new JLabel("Enter check-in date (MM-DD-YYYY):"));
        checkInField = new JTextField();
        inputPanel.add(checkInField);

        inputPanel.add(new JLabel("Enter check-out date (MM-DD-YYYY):"));
        checkOutField = new JTextField();
        inputPanel.add(checkOutField);
        // User selects suite

        // display the suite in order. Suites 1-5 are Venetian Tower, the rest
        // are Palazzo.
        inputPanel.add(new JLabel("Select a suite!"));
        suiteComboBox = new JComboBox<>(hotelData.suiteChoice);
        suiteComboBox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                updateSuiteImage();
            }
        });
        inputPanel.add(suiteComboBox);

        add(inputPanel, BorderLayout.NORTH);

        suiteImageLabel = new JLabel();
        add(suiteImageLabel, BorderLayout.CENTER);

        JPanel upgradePanel = new JPanel(new BorderLayout());
        upgradePanel.add(new JLabel("Select your upgrades!:"), BorderLayout.NORTH);
        upgradesArea = new JTextArea();
        upgradePanel.add(new JScrollPane(upgradesArea), BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        JButton bookButton = new JButton("Book Room");
        bookButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                bookRoom();
            }
        });
        buttonPanel.add(bookButton);
        upgradePanel.add(buttonPanel, BorderLayout.SOUTH);

        add(upgradePanel, BorderLayout.SOUTH);
    }

    // show the suite image(s) based on the user's selection
    private void updateSuiteImage() {
        int suiteIndex = suiteComboBox.getSelectedIndex();
        String imagePath = "/path/to/images/suite" + (suiteIndex + 1) + ".jpg"; // Update with actual image paths
        ImageIcon suiteImage = new ImageIcon(imagePath);
        suiteImageLabel.setIcon(suiteImage);
    }

    private void bookRoom() {
        String name = nameField.getText();
        String email = emailField.getText();
        String rewardsId = rewardsIdField.getText();
        String creditCard = creditCardField.getText();
        String checkInDate = checkInField.getText();
        String checkOutDate = checkOutField.getText();
        int suiteChoiceGuest = suiteComboBox.getSelectedIndex() + 1;

        Guest guest = new Guest(name, email, rewardsId, creditCard);
        ReservationService reservationService = new ReservationService();

        // Charge the guest the suite they selected
        switch (suiteChoiceGuest) {
            case 1:
                hotelData.SUITE_PRICE = hotelData.SUITE_RATES[0];
                break;
            case 2:
                hotelData.SUITE_PRICE = hotelData.SUITE_RATES[1];
                break;
            case 3:
                hotelData.SUITE_PRICE = hotelData.SUITE_RATES[2];
                break;
            case 4:
                hotelData.SUITE_PRICE = hotelData.SUITE_RATES[3];
                break;
            case 5:
                hotelData.SUITE_PRICE = hotelData.SUITE_RATES[4];
                break;
            case 6:
                hotelData.SUITE_PRICE = hotelData.SUITE_RATES[5];
                break;
            case 7:
                hotelData.SUITE_PRICE = hotelData.SUITE_RATES[6];
                break;
            case 8:
                hotelData.SUITE_PRICE = hotelData.SUITE_RATES[7];
                break;
            case 9:
                hotelData.SUITE_PRICE = hotelData.SUITE_RATES[8];
                break;
            case 10:
                hotelData.SUITE_PRICE = hotelData.SUITE_RATES[9];
                break;
            default:
                JOptionPane.showMessageDialog(this, "Invalid suite choice. Please select a suite from the list.");
                return;
        }

        // Add upgrade cost to room price
        String upgrades = upgradesArea.getText();
        for (char upgrade : upgrades.toCharArray()) {
            switch (upgrade) {
                case 'A':
                    hotelData.SUITE_PRICE += hotelData.UPGRADE_PRICES[0];
                    upgrades += hotelData.UPGRADE_SUITE[0];
                    break;
                case 'B':
                    hotelData.SUITE_PRICE += hotelData.UPGRADE_PRICES[1];
                    upgrades += hotelData.UPGRADE_SUITE[1];
                    break;
                case 'C':
                    hotelData.SUITE_PRICE += hotelData.UPGRADE_PRICES[2];
                    upgrades += hotelData.UPGRADE_SUITE[2];
                    break;
                case 'D':
                    hotelData.SUITE_PRICE += hotelData.UPGRADE_PRICES[3];
                    upgrades += hotelData.UPGRADE_SUITE[3];
                    break;
                default:
                    JOptionPane.showMessageDialog(this,
                            "No upgrade selected. Please Note, you may be still subject to the resort fee(s).\n");

                    return;
            }
        }

        // Calculate grand total
        double grandTotal = hotelData.SUITE_PRICE + hotelData.RESORT_FEE;

        // Book room with all aforementioned details of fees, extra amentities, and
        // object Room
        Room room = new Room(hotelData.suiteChoice[suiteChoiceGuest - 1], upgrades, grandTotal);
        Reservation reservation = reservationService.bookRoom(guest, room, checkInDate, checkOutDate);

        if (reservation != null) {
            JOptionPane.showMessageDialog(this, "Reservation successful! Total room charges: $" + grandTotal);
            FileUtil.saveReservationToFile(reservation);
        } else {
            JOptionPane.showMessageDialog(this, "Reservation failed. Please check your details and try again.");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new Booking().setVisible(true);
            }
        });
    }
}

// Pseudocode
// 1. Prompt user for name, email, rewards ID, and credit card.
// 2. Display suite options and allow user to select one.
// 3. Ask for check-in and check-out dates.
// 4. Validate input and attempt to book room.
// 5. If booking is successful, save confirmation to text file and display a
// success message.
// 6. If booking fails, inform the user and prompt for corrections.
