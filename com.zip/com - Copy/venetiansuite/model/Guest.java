/* Final Project: Venetian Resort Guest Personal Information.
By Katelyn H. */

package com.venetiansuite.model;

public class Guest {
    // PII of guest + billing info
    private String name;
    private String email;
    private String rewardsId;
    private String creditCard;

    // Constructor, getters, and setters

    public Guest(String name, String email, String rewardsId, String creditCard) {
        this.name = name;
        this.email = email;
        this.rewardsId = rewardsId;
        this.creditCard = creditCard;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getRewardsId() {
        return rewardsId;
    }

    public String getCreditCard() {
        return creditCard;
    }
}