/* Final Project: Venetian Suites Charges 
By Katelyn H. */

package com.venetiansuite.model;

public class Room {
    private String suiteType;
    private String upgrades;
    private double totalPrice;

    // Constructor, getters, and setters

    public Room(String suiteType, String upgrades, double totalPrice) {
        this.suiteType = suiteType;
        this.upgrades = upgrades;
        this.totalPrice = totalPrice;
    }

    public String getSuiteType() {
        return suiteType;
    }

    public void setSuiteType(String suiteType) {
        this.suiteType = suiteType;
    }

    public String getUpgrades() {
        return upgrades;
    }

    public void setUpgrades(String upgrades) {
        this.upgrades = upgrades;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }
}