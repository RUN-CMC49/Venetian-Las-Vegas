/* Final Project: Venetian Resort Guest Personal Information.
By Katelyn H. */

package com.venetiansuite.model;

public class Reservation {
    private Guest guest; // tie in all guest PII
    private Room room; // all room rate and fees
    private String checkInDate;
    private String checkOutDate;

    // Constructor, getters, and setters

    public Reservation(Guest guest, Room room, String checkInDate, String checkOutDate) {
        this.guest = guest;
        this.room = room;
        this.checkInDate = checkInDate;
        this.checkOutDate = checkOutDate;
    }

    public Guest getGuest() {
        return guest;
    }

    public Room getRoom() {
        return room;
    }

    public String getCheckInDate() {
        return checkInDate;
    }

    public String getCheckOutDate() {
        return checkOutDate;
    }
}